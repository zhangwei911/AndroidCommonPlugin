### FaceBase[![Download](https://api.bintray.com/packages/{organization}/{repo}/{ARTIFACT_ID}/images/download.svg)](https://bintray.com/{organization}/{repo}/{ARTIFACT_ID}/_latestVersion)

gradle引用
```
implementation '{GROUP_ID}:{ARTIFACT_ID}:{LIB_VERSION}'
```